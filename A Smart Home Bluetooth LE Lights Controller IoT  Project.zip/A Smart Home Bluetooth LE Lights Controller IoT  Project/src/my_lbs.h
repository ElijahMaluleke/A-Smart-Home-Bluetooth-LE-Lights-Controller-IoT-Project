
#ifndef BT_LBS_H
#define BT_LBS_H


#ifdef __cplusplus
extern "C"
{
#endif

#include <zephyr/types.h>

#define BT_UUID_LBS_VAL \
    BT_UUID_128_ENCODE(0x00001523, 0x1212, 0xefde, 0x1523, 0x785feabcd123)

#define BT_UUID_LBS_BUTTON_VAL \
    BT_UUID_128_ENCODE(0x00001524, 0x1212, 0xefde, 0x1523, 0x785feabcd123)


#define BT_UUID_LBS_LED_VAL \
    BT_UUID_128_ENCODE(0x00001525, 0x1212, 0xefde, 0x1523, 0x785feabcd123)


#define BT_UUID_LBS_RED_LED_VAL \
    BT_UUID_128_ENCODE(0x00001526, 0x1212, 0xefde, 0x1523, 0x785feabcd123)


#define BT_UUID_LBS_YELLOW_LED_VAL \
    BT_UUID_128_ENCODE(0x00001527, 0x1212, 0xefde, 0x1523, 0x785feabcd123)


#define BT_UUID_LBS_GREEN_LED_VAL \
    BT_UUID_128_ENCODE(0x00001528, 0x1212, 0xefde, 0x1523, 0x785feabcd123)


#define BT_UUID_LBS_LIGHT_1_VAL \
    BT_UUID_128_ENCODE(0x00001529, 0x1212, 0xefde, 0x1523, 0x785feabcd123)


#define BT_UUID_LBS_LIGHT_2_VAL \
    BT_UUID_128_ENCODE(0x0000152A, 0x1212, 0xefde, 0x1523, 0x785feabcd123)

#define BT_UUID_LBS BT_UUID_DECLARE_128(BT_UUID_LBS_VAL)
#define BT_UUID_LBS_BUTTON BT_UUID_DECLARE_128(BT_UUID_LBS_BUTTON_VAL)
#define BT_UUID_LBS_LED BT_UUID_DECLARE_128(BT_UUID_LBS_LED_VAL)

#define BT_UUID_LBS_RED_LED BT_UUID_DECLARE_128(BT_UUID_LBS_RED_LED_VAL)
#define BT_UUID_LBS_YELLOW_LED BT_UUID_DECLARE_128(BT_UUID_LBS_YELLOW_LED_VAL)
#define BT_UUID_LBS_GREEN_LED BT_UUID_DECLARE_128(BT_UUID_LBS_GREEN_LED_VAL)


#define BT_UUID_LBS_LIGHT_1 BT_UUID_DECLARE_128(BT_UUID_LBS_LIGHT_1_VAL)
#define BT_UUID_LBS_LIGHT_2 BT_UUID_DECLARE_128(BT_UUID_LBS_LIGHT_2_VAL)


    typedef void (*led_cb_t)(const bool led_state);

    typedef bool (*button_cb_t)(void);

    struct my_lbs_cb
    {
        led_cb_t led_cb;
        led_cb_t red_led_cb;
        led_cb_t yellow_led_cb;
        led_cb_t green_led_cb;
        led_cb_t light_1_cb;
        led_cb_t light_2_cb;
        button_cb_t button_cb;
    };

    int my_lbs_init(struct my_lbs_cb *callbacks);

#ifdef __cplusplus
}
#endif


#endif 
